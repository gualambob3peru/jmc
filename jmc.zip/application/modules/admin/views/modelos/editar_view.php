<div class="row">
    <div class="col-md-12">



    </div>
</div>

<br>

<div class="card">
    <h5 class="card-header">Editar Modelos</h5>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <form method="post">
                    <?php helper_form_select("idMarcas","Marca",$marcas,"descripcion",$model->idMarcas ) ?>
                    <?php helper_form_text("descripcion","Descripción",$model->descripcion) ?>
                    

                    <button type="submit" class="btn btn-outline-success"><i class="fas fa-save"></i> Guardar</button>
                </form>
            </div>
        </div>

    </div>

</div>